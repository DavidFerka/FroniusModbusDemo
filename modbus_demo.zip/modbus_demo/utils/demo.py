"""
@author:         M. David Ferka
@detail:         

@created:     
@modified:
@version:     

@change:

@license: Copyright (c) 2021 mdf

@todo:


"""

from devices import inverter_demo

inverter = inverter_demo.InverterDemo()
gui_stopped = False